//dec
var express = require('express');
var bodyParser = require('body-parser');
var exSession = require('express-session');
var login = require('./controller/loginController')
var home = require('./controller/homeController')
var app = express();

//config
app.set('view engine', 'ejs');


//middleware
app.use(bodyParser.urlencoded({extended: true}));
app.use(exSession({secret: 'anything', saveUninitialized: true, resave: false}))
app.use('/login', login);
app.use('/home', home);


//routes
app.get('/', (req, res)=>{
	res.render('index');
});




//server start
app.listen(3000, ()=>{
	console.log('server started at 3000');
})