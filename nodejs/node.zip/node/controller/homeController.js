var express = require('express');
var router = express.Router();

router.get('/', (req, res)=>{

	if(req.session.un != null){
		res.render('home/index', {uname: 'alamin'});
	}else{
		res.redirect('/login');
	}
	
});

router.get('/:abc', (req, res)=>{

	console.log(req.params.abc);
	
});

module.exports = router;