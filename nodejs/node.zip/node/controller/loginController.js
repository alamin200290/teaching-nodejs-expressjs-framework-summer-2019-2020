var express = require('express');
var router = express.Router();

router.get('/', (req, res)=>{
	res.render('login/index');
});

router.post('/', (req, res)=>{
	if(req.body.uname == req.body.password){
		req.session.un = req.body.uname;
		res.redirect('/home');
	}
});


module.exports = router;